# BLINDSPOT

**A performance monitor that checks whether its own evidence is usable.**

A local Python remake of the supplied HMS prototype for the BLINDSPOT project brief.
It measures observed thumb/index tapping, audits tracking quality, and compares only
eligible prior sessions. It is an engineering demonstration, not a medical device.

## Start the dashboard

Python 3.11 or 3.12 is recommended. Run these commands from this extracted project folder:

```sh
python -m venv .venv
# macOS / Linux:
source .venv/bin/activate
# Windows PowerShell instead:
# .venv\Scripts\Activate.ps1

python -m pip install -e .
streamlit run app.py
```

Open **http://127.0.0.1:8501**. Start with **Fault lab → Run fault demonstration**.
The clean case has 30 cycles; hiding the hand for five seconds produces 20 observed
cycles and **Insufficient evidence**, rather than a claim of reduced performance.

Dependencies need internet during installation. After setup, the dashboard, research
notes, storage and synthetic demonstrations work without internet access. No API key
is needed. Streamlit usage statistics are disabled and the server binds to loopback.

## Enable the webcam

```sh
python -m pip install -e ".[camera]"
python -m blindspot prepare-camera
streamlit run app.py
```

The source ZIP includes `models/hand_landmarker.task`, so model preparation simply
verifies its checksum. If using the wheel or a checkout without that asset, the same
command downloads Google's versioned model once. Do this before going offline.

On Linux, MediaPipe also needs system graphics libraries. On Ubuntu/Debian a typical
setup is `sudo apt-get install libegl1 libgles2 libgl1`. These are OS dependencies,
not pip packages. macOS/Windows users should allow camera access in system settings.

Use **Assessment**. Enter a participant code, choose the physical hand and camera index,
then start. Hold exactly one complete hand in frame, with the palm facing the camera.
Open the thumb/index separation clearly between touches. The preview is mirrored.
The selected hand must match MediaPipe's classification; verify it on your own camera.
Keep hand, posture, lighting and camera placement consistent between sessions.

Capture runs for 15 seconds. The progress text reports observed cycles and availability.
Camera/model failures produce recovery guidance; the Fault lab remains available.
The camera belongs to the machine running Python. A remotely hosted dashboard does not
use the viewer's webcam. Run locally as instructed above.

## Personal baselines and saved evidence

- Choose **Save session** explicitly. Only summaries and evidence receipts are persisted.
- Record at least **three** eligible webcam sessions, then a fourth for comparison.
- Baselines use up to 20 prior usable sessions within 30 days, with matching participant,
  hand, source, and full protocol fingerprint. Every candidate is rechecked for eligibility.
- Unreliable, stale, future, mismatched and synthetic sessions cannot enter webcam baselines.
- Change is the observed rate versus the median, expressed descriptively. No medical
  threshold, fatigue prediction, clinical probability or diagnosis is provided.
- A true zero baseline has no defined percentage change. Missing rates remain null.
- Fault lab references are three labelled synthetic fixtures included in its receipt.

**Session log** shows 10 records per page and exports saved receipts. A receipt contains
algorithm/policy versions, count, coverage, gaps, interpretation, baseline IDs, NASA context
and model provenance. Lab receipts also include the reference summaries. Saving again
with the same session ID cannot duplicate or overwrite its evidence.

SQLite defaults to `data/blindspot.db`. Set `BLINDSPOT_DB` to choose a different local path.
It is not encrypted. Use participant codes rather than names. No raw images, landmarks,
or video are saved; tap timestamps and aggregate evidence are retained in saved summaries.
No app telemetry or external service is used during normal operation. Model preparation
is the only explicit app download. Research links open externally only when clicked.

## Command-line demonstrations

```sh
python -m blindspot demo
python -m blindspot demo --scenario clean
python -m blindspot demo --scenario stale_stream --output receipt.json
python -m blindspot capture --participant P01 --hand Right --save
```

Faults: `clean`, `tracking_loss`, `stale_stream`, `low_confidence`, `replayed_frames`.
The demo needs no camera, model, NumPy, SciPy or network. Its numeric results are deterministic;
receipt IDs and creation times intentionally identify each separate run.

## What changed from HMS

The original HMS archive remains separate. BLINDSPOT adapts its SQLite WAL,
parameterized-query and locking patterns. It adds independent modules for acquisition,
counting, validation, evidence quality, eligible baselines, fault injection, storage,
research provenance and the dashboard. HMS clinical-looking alerts, heuristic risk
scores, synthetic vital signs, ECG, MQTT, REST API and PyQt UI are not part of this build.
See `SPEC.md`, `DESIGN.md`, `UX-CONTRACT.md` and `NOTICE.md`.

## NASA integration

The bundled research adapter uses NASA's
[Sensorimotor Risk resource](https://www.nasa.gov/directorates/esdmd/hhp/sensorimotor-risk/)
to explain why hand-movement performance is relevant to the project. Its offline note,
source URL, access date, task rationale and content hash appear in Research and every
receipt. This is **research-context integration**, not an astronaut dataset or a NASA
validated tapping protocol. It supplies no clinical or quality thresholds.

## Scientific and technical limits

Quality settings (80% coverage, 1-second gaps/expiry, 15-second task, three-session baseline)
are explicit prototype engineering choices, not empirically established medical limits.
Usability checks detect presence, clipping, gaps and timing/sequence problems. They do
not establish measurement accuracy. Repeated distances alone are never labelled failure.
Plausible but wrong landmarks, camera buffering, incorrect handedness, perspective,
lighting and subtle tracking errors can escape detection. Two-dimensional distance
normalized by apparent palm width is sensitive to hand orientation.

Webcam confidence is a **binary geometry/presence flag**, not a calibrated probability.
MediaPipe's handedness score is not misrepresented as tracking confidence. Live capture
uses actual monotonic timestamps; delayed frames reduce coverage instead of being
backfilled. A frozen image with fresh sequence IDs is not reliably detectable here.
Comparisons cannot identify a cause or establish astronaut fitness. Human participant,
real camera accuracy, test/retest reliability and spaceflight validation remain future work.

## Verify

```sh
python -m pip install -e ".[camera,dev]"
python -m pytest -q
ruff check .
ruff format --check .
mypy blindspot
python -m build
```

Optional real browser check, with Chromium installed and the dashboard running:

```sh
# Linux default browser path is /usr/bin/chromium; override CHROMIUM_PATH elsewhere.
python tests/browser_check.py http://127.0.0.1:8501
```

The browser check creates a synthetic saved session, verifies receipt download, camera
failure handling, keyboard focus and a narrow layout, and writes `verification/browser/`.
Use a temporary `BLINDSPOT_DB` when running it. It does not require a working webcam.
See `verification/RESULTS.md` for checks actually performed on this delivery.

## Five-minute demonstration

1. State the question: can a lower count be trusted?
2. Run clean Fault lab: 30 cycles and comparable synthetic evidence.
3. Hide the synthetic hand: 20 cycles, a count-only apparent drop, insufficient evidence.
4. Show the missing interval, then stream expiry or sequence replay.
5. If a local camera has been rehearsed, run one 15-second tapping assessment.
6. Download the receipt; show NASA provenance and explain limitations.

AI assistance was used to design, implement and review this remake. Disclose it and the
pre-existing HMS work in competition materials. Current competition eligibility and
submission requirements have not been independently verified.
