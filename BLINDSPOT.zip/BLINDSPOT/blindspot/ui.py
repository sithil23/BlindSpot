"""Shared Streamlit views: evidence first, measurement second, interpretation last."""

import json
import os
import re
import sqlite3
from dataclasses import asdict
from datetime import datetime
from importlib.resources import files
from pathlib import Path
from zoneinfo import ZoneInfo

import streamlit as st

from blindspot.assessment import assess
from blindspot.camera import DEFAULT_MODEL, CameraUnavailable, capture
from blindspot.evidence import REASONS
from blindspot.lab import run_lab
from blindspot.models import Observation, Protocol, usable
from blindspot.nasa import research_context
from blindspot.sessions import Session, compare
from blindspot.storage import SessionStore
from blindspot.synthetic import SCENARIOS
from blindspot.tapping import TapCounter


def stylesheet() -> str:
    return files("blindspot").joinpath("assets/theme.css").read_text(encoding="utf-8")


def trace_svg(frames: list[Observation], policy: Protocol) -> str:
    """A gap-preserving trace with text alternatives; no user text enters the markup."""
    tokens = dict(re.findall(r"--bs-([\w-]+):\s*(#[0-9a-f]+)", stylesheet()))
    expected = round(policy.duration_s * policy.fps)
    valid_bins = set()
    paths: list[list[str]] = []
    segment: list[str] = []
    last_seq = -1
    last_t = -1.0
    for frame in frames:
        valid = usable(frame, policy) and frame.seq > last_seq and frame.t > last_t
        if valid and last_t >= 0 and frame.t - last_t > policy.bridge_gap_s:
            if segment:
                paths.append(segment)
            segment = []
        if valid:
            valid_bins.add(int(frame.t * policy.fps + 1e-7))
            x = 30 + frame.t / policy.duration_s * 840
            y = 140 - min(frame.distance or 0, 1.2) / 1.2 * 90
            segment.append(f"{x:.1f},{y:.1f}")
        elif segment:
            paths.append(segment)
            segment = []
        last_seq = max(last_seq, frame.seq)
        last_t = max(last_t, frame.t)
    if segment:
        paths.append(segment)
    lines = "".join(
        f'<polyline points="{" ".join(p)}" fill="none" '
        f'stroke="{tokens["primary"]}" stroke-width="2" />'
        for p in paths
    )
    strip = "".join(
        f'<rect x="{30 + i / expected * 840:.2f}" y="30" '
        f'width="{840 / expected + 0.1:.2f}" height="20" '
        f'fill="{tokens["success"] if i in valid_bins else tokens["warning"]}" />'
        for i in range(expected)
    )
    return (
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 900 178" role="img" '
        'aria-labelledby="trace-title trace-description">'
        '<title id="trace-title">Hand movement and usable tracking over time</title>'
        f"<style>text {{ font-family: monospace; fill: {tokens['muted']}; "
        "font-size: 12px; }</style>"
        '<desc id="trace-description">Upper band shows usable tracking in teal and missing '
        "or rejected frames in amber. Blue curve shows normalized finger separation. "
        "Gaps are preserved. Coverage and longest gap are also reported as text below.</desc>"
        f'<text x="30" y="18">TRACKING AVAILABILITY</text>{strip}{lines}'
        '<text x="30" y="168">0 s</text>'
        f'<text x="825" y="168">{policy.duration_s:g} s</text></svg>'
    )


def render_result(bundle, policy: Protocol, store: SessionStore):
    session, frames, comparison, receipt, basic = bundle
    result = session.assessment
    st.caption(
        f"{session.source.upper()} · {session.participant} · "
        f"{receipt['policy']['hand']} hand · session {session.id[:8]}"
    )
    st.image(
        trace_svg(frames, policy),
        alt="Hand movement and usable tracking over time",
        caption="Tracking: teal = usable, amber = missing or rejected. "
        "Blue line = normalized finger separation. Gaps stay visible.",
        width="stretch",
    )
    metrics = st.columns(4)
    metrics[0].metric("Observed cycles", str(result.count) if result.rate_hz is not None else "—")
    metrics[1].metric("Usable tracking", f"{result.evidence.coverage:.0%}")
    metrics[2].metric("Longest tracking gap", f"{result.evidence.longest_gap_s:.2f} s")
    metrics[3].metric("Elapsed assessment", f"{result.duration_s:.1f} s")
    if comparison.status == "insufficient_evidence":
        st.warning(comparison.explanation)
        for reason in result.evidence.reasons:
            st.write("• " + REASONS[reason])
    elif comparison.status == "baseline_needed":
        st.info(comparison.explanation)
    else:
        st.success(comparison.explanation)
    if basic:
        with st.container(border=True):
            st.markdown("**What a basic monitor would show**")
            st.write(basic)
            st.caption(
                "This deliberately ignores evidence quality. It is not a medical comparator."
            )
    if not result.evidence.sufficient:
        st.caption(
            "Observed cycles are a partial count. Missing time is never filled with normal data "
            "or extrapolated into a full-session rate."
        )
    st.caption(
        "Prototype quality settings: ≥80% usable tracking, no gap >1 s, "
        "stream age ≤1 s, full 15 s assessment. "
        "These are engineering settings, not clinical limits."
    )
    left, right = st.columns(2)
    saved = store.get(session.id) is not None
    if left.button(
        "Session saved" if saved else "Save session",
        disabled=saved,
        key=f"save-{session.id}",
        width="stretch",
    ):
        try:
            store.save(session, receipt)
            st.success(
                "Session saved. The summary and evidence receipt are available in Session log."
            )
        except (sqlite3.Error, OSError):
            st.error(
                "Session could not be saved. Check the database folder permissions and retry. "
                "You can still download the receipt."
            )
    right.download_button(
        "Download evidence receipt",
        json.dumps(receipt, indent=2, allow_nan=False),
        file_name=f"blindspot-{session.id[:8]}.json",
        mime="application/json",
        key=f"download-{session.id}",
        width="stretch",
    )
    with st.expander("Inspect the evidence receipt"):
        st.json(receipt, expanded=False)


def assessment_view(store: SessionStore):
    st.subheader("Measure a tapping session")
    st.write(
        "Touch your index finger to your thumb, then open them fully. "
        "Each open–close–open movement is one cycle. Keep one hand fully in view."
    )
    st.caption(
        "Run Python on your own computer: this uses that computer’s webcam. "
        "No video or images are saved. Only explicitly saved summaries enter the local log."
    )
    a, b, c = st.columns([2, 1, 1])
    participant = a.text_input(
        "Participant code",
        value="P01",
        max_chars=64,
        help="Use a code rather than a name. Stored locally only when you save.",
    )
    hand = b.radio("Hand to assess", ["Right", "Left"], horizontal=True)
    camera_index = c.number_input("Camera index", min_value=0, max_value=9, value=0, step=1)
    policy = Protocol(hand=hand)
    if not DEFAULT_MODEL.exists():
        st.info(
            "Camera setup needed: install the camera extras and run "
            "`python -m blindspot prepare-camera` once. The Fault lab works without a camera."
        )
    start = st.button("Start 15-second assessment", type="primary")
    progress = st.empty()
    preview = st.empty()
    if start:
        if not participant.strip():
            st.error("Enter a participant code before starting.")
        else:
            try:
                # Initialization can take a few seconds; capture clock starts after it finishes.
                live_counter = TapCounter(policy)
                last_preview = -1.0

                def on_frame(t, frame, rgb):
                    nonlocal last_preview
                    live_counter.update(frame)
                    progress.progress(
                        min(1.0, t / policy.duration_s),
                        text=f"{t:.1f} / 15 s · {live_counter.count} observed cycles · "
                        f"{'hand visible' if usable(frame, policy) else 'tracking unavailable'}",
                    )
                    if rgb is not None and t - last_preview > 0.2:
                        preview.image(
                            rgb, caption="Local camera preview · no video saved", width=640
                        )
                        last_preview = t

                with st.spinner("Opening local camera. Hold your hand ready."):
                    captured = capture(policy, camera_index=int(camera_index), progress=on_frame)
                session = Session.create(
                    participant,
                    "webcam",
                    policy,
                    assess(captured.frames, policy, captured.duration_s),
                    metadata=captured.metadata,
                )
                comparison = compare(session, store.baseline_candidates(session, policy), policy)
                st.session_state.camera_result = (
                    session,
                    captured.frames,
                    comparison,
                    session.receipt(comparison, policy),
                    None,
                )
                st.session_state.camera_policy = policy
            except CameraUnavailable as exc:
                st.error(str(exc))
            finally:
                progress.empty()
                preview.empty()
    if "camera_result" in st.session_state:
        render_result(st.session_state.camera_result, st.session_state.camera_policy, store)
    else:
        st.info(
            "No assessment yet. Start a local camera session, "
            "or open Fault lab for a repeatable demo."
        )


def lab_view(store: SessionStore):
    st.subheader("Break the measurement, keep the motion")
    st.write(
        "The same synthetic hand completes 30 cycles in 15 seconds. "
        "Change only the tracking evidence and compare the interpretations."
    )
    st.caption(
        "SYNTHETIC · No astronaut or patient data · Three clean synthetic reference sessions"
    )
    scenario = st.radio(
        "Inject a measurement fault",
        list(SCENARIOS),
        index=1,
        format_func=SCENARIOS.get,
        horizontal=True,
    )
    if st.button("Run fault demonstration", type="primary"):
        st.session_state.lab_result = run_lab(scenario)
    if "lab_result" in st.session_state:
        render_result(st.session_state.lab_result, Protocol(), store)
    else:
        st.info("Choose a fault and run the demonstration. No camera or internet is needed.")


def history_view(store: SessionStore):
    st.subheader("Session log")
    st.caption("Local summaries only · Explicit saves · Times shown in Asia/Colombo (UTC+05:30)")
    total = store.count()
    if not total:
        st.info(
            "No saved sessions. Run an assessment or fault demonstration, then choose Save session."
        )
        return
    page = min(st.session_state.get("history_page", 0), (total - 1) // 10)
    rows = store.recent(limit=10, offset=page * 10)
    st.write(f"Showing {page * 10 + 1}–{min((page + 1) * 10, total)} of {total} sessions")
    for session in rows:
        stamp = datetime.fromtimestamp(session.created_at, ZoneInfo("Asia/Colombo")).strftime(
            "%d %b %Y %H:%M"
        )
        quality = (
            "Usable evidence" if session.assessment.evidence.sufficient else "Insufficient evidence"
        )
        label = f"{stamp} · {session.participant} · {session.source} · {quality}"
        with st.expander(label):
            st.write(
                f"Observed cycles: {session.assessment.count} · "
                f"Usable tracking: {session.assessment.evidence.coverage:.0%}"
            )
            receipt = store.receipt(session.id)
            if receipt:
                st.write(receipt["comparison"]["explanation"])
                st.download_button(
                    "Download saved receipt",
                    json.dumps(receipt, indent=2),
                    file_name=f"blindspot-{session.id[:8]}.json",
                    mime="application/json",
                    key=f"history-{session.id}",
                )
            else:
                st.caption("This session has no saved receipt.")
    previous, next_page, _ = st.columns([1, 1, 3])
    if previous.button("Previous page", disabled=page == 0):
        st.session_state.history_page = page - 1
        st.rerun()
    if next_page.button("Next page", disabled=(page + 1) * 10 >= total):
        st.session_state.history_page = page + 1
        st.rerun()


def research_view():
    st.subheader("Research context and boundaries")
    source = research_context()
    st.markdown(f"**[{source['title']}]({source['url']})**")
    st.write(source["summary"])
    st.write(source["application"])
    st.info(source["limitations"])
    st.caption(
        f"Offline research note · accessed {source['accessed']} · "
        f"fingerprint {source['content_sha256'][:12]}"
    )
    st.markdown("**What the prototype can establish**")
    st.write(
        "A count of observed hand movements, measured tracking availability, "
        "and a descriptive comparison with eligible prior sessions."
    )
    st.markdown("**What it cannot establish**")
    st.write(
        "A diagnosis, fatigue level, cause of a change, readiness for duty, or reliability "
        "under spaceflight conditions. Occlusion, camera angle, lighting and hand "
        "classification can affect results. Persistent wrong landmarks can pass the audit."
    )
    with st.expander("Measurement policy and baseline rules"):
        st.json(asdict(Protocol()))
        st.write(
            "Use the same hand, camera placement and movement instructions. "
            "The baseline uses the most recent 20 eligible prior sessions within 30 days, "
            "with at least three required. Synthetic and webcam baselines are separated. "
            "Equal measured values alone never imply sensor failure."
        )
    st.caption(
        "Developed with AI assistance. Disclose that assistance and the reused HMS "
        "storage pattern in competition materials. Verify current event rules separately."
    )


def main():
    st.set_page_config(page_title="BLINDSPOT · Measurement workbench", page_icon="◉", layout="wide")
    st.markdown(f"<style>{stylesheet()}</style>", unsafe_allow_html=True)
    st.caption("◉ BLINDSPOT / PERFORMANCE & EVIDENCE")
    st.title("Can we trust this measurement?")
    st.write("A performance monitor that checks its own evidence before drawing a conclusion.")
    st.html('<p class="local-note">LOCAL PROCESSING / NO VIDEO STORED / RESEARCH PROTOTYPE</p>')
    assessment, lab, history, research = st.tabs(
        ["Assessment", "Fault lab", "Session log", "Research"]
    )
    try:
        with SessionStore(Path(os.environ.get("BLINDSPOT_DB", "data/blindspot.db"))) as store:
            with assessment:
                assessment_view(store)
            with lab:
                lab_view(store)
            with history:
                history_view(store)
            with research:
                research_view()
    except (sqlite3.Error, OSError):
        st.error(
            "Local storage is unavailable. Check that the data folder is writable, "
            "then reload. For a storage-free demo, run `python -m blindspot demo`."
        )
    st.divider()
    st.caption(
        "BLINDSPOT 0.1 · Engineering demonstration only. "
        "Not a medical device or a flight decision tool."
    )
